import bpy
import sys
import subprocess
import importlib.util
import importlib.metadata

# ------------------------------------------------------------------------
# CONFIGURATION
# ------------------------------------------------------------------------

REQUIRED_LIBRARIES = [
    "gphoto2",
    "opencv-python",
    "numpy",
    "pillow"
]

# ------------------------------------------------------------------------
# UTILITIES
# ------------------------------------------------------------------------

def is_library_installed(lib_name):
    try:
        spec = importlib.util.find_spec(lib_name)
        return spec is not None
    except Exception:
        return False

def get_library_version(lib_name):
    try:
        return importlib.metadata.version(lib_name)
    except importlib.metadata.PackageNotFoundError:
        return None

def any_missing_libraries():
    return [lib for lib in REQUIRED_LIBRARIES if not is_library_installed(lib)]

def print_console_header():
    print("\n" + "=" * 70)
    print("  BIME - Blender Image Management Environment")
    print("=" * 70 + "\n")

# ------------------------------------------------------------------------
# OPERATORS
# ------------------------------------------------------------------------

class BIME_OT_InstallLibraries(bpy.types.Operator):
    """Install all required Python libraries for BIME"""
    bl_idname = "bime.install_libraries"
    bl_label = "Install BIME Packages"

    def execute(self, context):
        print_console_header()
        print("Installing required libraries...")
        print("Run Blender from terminal using './blender' to see live output.\n")

        python_exe = sys.executable
        missing = any_missing_libraries()

        if missing:
            print(f"Detected missing libraries: {missing}\n")
        else:
            print("All libraries already present, reinstalling anyway.\n")

        try:
            subprocess.check_call(
                [python_exe, "-m", "pip", "install"] + REQUIRED_LIBRARIES,
                stdout=sys.stdout,
                stderr=sys.stderr
            )
            print("\n✅ Installation complete. Please restart Blender.\n")
            self.report({'INFO'}, "BIME libraries installed successfully.")
        except subprocess.CalledProcessError as e:
            print(f"\n❌ Installation failed. Error:\n{e}\n")
            self.report({'ERROR'}, "Installation failed. Check console output.")
            return {'CANCELLED'}

        return {'FINISHED'}


class BIME_OT_UpdateLibraries(bpy.types.Operator):
    """Update or reinstall all BIME Python libraries"""
    bl_idname = "bime.update_libraries"
    bl_label = "Update / Reinstall BIME Packages"

    def execute(self, context):
        print_console_header()
        print("Updating / Reinstalling libraries...")
        python_exe = sys.executable

        try:
            subprocess.check_call(
                [python_exe, "-m", "pip", "install", "--upgrade"] + REQUIRED_LIBRARIES,
                stdout=sys.stdout,
                stderr=sys.stderr
            )
            print("\n✅ Update complete. Please restart Blender.\n")
            self.report({'INFO'}, "BIME libraries updated successfully.")
        except subprocess.CalledProcessError as e:
            print(f"\n❌ Update failed. Error:\n{e}\n")
            self.report({'ERROR'}, "Update failed. Check console output.")
            return {'CANCELLED'}

        return {'FINISHED'}


class BIME_OT_UninstallLibraries(bpy.types.Operator):
    """Uninstall all BIME Python libraries"""
    bl_idname = "bime.uninstall_libraries"
    bl_label = "Uninstall BIME Packages"

    def execute(self, context):
        print_console_header()
        print("Uninstalling libraries...\n")
        python_exe = sys.executable

        try:
            subprocess.check_call(
                [python_exe, "-m", "pip", "uninstall", "-y"] + REQUIRED_LIBRARIES,
                stdout=sys.stdout,
                stderr=sys.stderr
            )
            print("\n✅ Uninstallation complete.\n")
            self.report({'INFO'}, "BIME libraries uninstalled successfully.")
        except subprocess.CalledProcessError as e:
            print(f"\n❌ Uninstallation failed. Error:\n{e}\n")
            self.report({'ERROR'}, "Uninstallation failed. Check console output.")
            return {'CANCELLED'}

        return {'FINISHED'}

# ------------------------------------------------------------------------
# PREFERENCES PANEL
# ------------------------------------------------------------------------

class BIME_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__ or "bime"

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Blender Image Management Environment (BIME)", icon='CAMERA_DATA')
        box.label(text="Recommended: run Blender from console ('./blender') to see progress.")
        box.separator()

        col = box.column(align=True)

        installed_libs = []
        missing_libs = []

        for lib in REQUIRED_LIBRARIES:
            version = get_library_version(lib)
            if version:
                installed_libs.append((lib, version))
            else:
                missing_libs.append(lib)

        if installed_libs:
            col.label(text="Installed libraries:", icon='CHECKMARK')
            for name, ver in installed_libs:
                col.label(text=f"• {name} ({ver})", icon='FILE_TICK')
        else:
            col.label(text="No libraries detected.", icon='ERROR')

        if missing_libs:
            col.separator()
            col.label(text="Missing libraries:", icon='ERROR')
            for name in missing_libs:
                col.label(text=f"• {name}")

        col.separator()

        row = col.row(align=True)
        if missing_libs:
            row.operator(BIME_OT_InstallLibraries.bl_idname, icon='ADD')
        else:
            row.operator(BIME_OT_UpdateLibraries.bl_idname, icon='FILE_REFRESH')

        row = col.row(align=True)
        row.operator(BIME_OT_UninstallLibraries.bl_idname, icon='REMOVE')

# ------------------------------------------------------------------------
# REGISTRATION
# ------------------------------------------------------------------------

classes = (
    BIME_OT_InstallLibraries,
    BIME_OT_UpdateLibraries,
    BIME_OT_UninstallLibraries,
    BIME_AddonPreferences,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
