bl_info = {
    "name": "BIME - Blender Image Management Environment",
    "author": "David & Chatie",
    "version": (1, 0, 0),
    "blender": (4, 0, 0),
    "location": "Preferences > Add-ons",
    "description": "Installs and manages Python libraries required for BIME / Stop Motion camera integration.",
    "category": "System"
}

import importlib
from . import bime_installer
importlib.reload(bime_installer)

def register():
    bime_installer.register()

def unregister():
    bime_installer.unregister()

if __name__ == "__main__":
    register()
